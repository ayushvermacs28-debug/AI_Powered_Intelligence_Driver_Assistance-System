# YOLOv11 Pothole Detection

## Project Description
This module detects potholes in road images using the YOLOv11n object detection model.

## Dataset
- 665 road images
- XML annotations
- Converted into YOLO annotation format
- Training, validation and testing split

## Technologies Used
- Python
- YOLOv11n
- Ultralytics
- OpenCV

## Model Training
- Epochs: 20
- Hardware: CPU
- Number of classes: 1 (Pothole)

## Model Performance

| Metric | Result |
|---|---:|
| Precision | 74.8% |
| Recall | 72.1% |
| mAP@50 | 78.3% |
| mAP@50–95 | 48.2% |

*These are validation results.*

## Output
The trained model detects potholes and marks their locations using bounding boxes.

## Model Weights
The trained model is provided as `best.pt`.